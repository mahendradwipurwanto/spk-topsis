﻿/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'uk', {
	copy: 'Copyright &copy; $1. Всі права застережено.',
	dlgTitle: 'Про CKEditor 4',
	moreInfo: 'Щодо інформації з ліцензування завітайте на наш сайт:'
} );
